print('Hello world')
