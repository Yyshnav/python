student={"name":"Niranjan","age":21,"sem":1,"roll no":4}
print(student)
print(len(student))
print(student.keys())
print(student.values())
print(student.items())
student.update({"gender":"male"})
print(student)
