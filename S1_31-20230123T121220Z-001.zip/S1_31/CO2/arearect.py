def area():
    l=int(input("Enter the length"))
    b=int(input("Enter the breadth"))
    a=l*b
    print("area of rectangle=",a)

area()
