name=input("Enter a string")
print(name[-1:]+name[1:-1]+name[:1])
