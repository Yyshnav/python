a={2,4,6,8,10}
b={1,4,9,16,25,36,49,64,81,100}
print(a.union(b))
print(a.intersection(b))
print(a.difference(b))