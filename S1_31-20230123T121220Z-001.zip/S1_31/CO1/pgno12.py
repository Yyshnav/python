n=input("Enter the file name")
a=n.split('.')
print(a[1])
