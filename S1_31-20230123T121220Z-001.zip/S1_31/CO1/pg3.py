name="Niranjan"
print(len(name))
print(name[2])
print(name.upper())
