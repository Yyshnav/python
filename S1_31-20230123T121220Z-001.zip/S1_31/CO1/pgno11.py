a=int(input("enter first number"))
b=int(input("enter second number"))
c=int(input("enter third number"))
if(a>b & a>c):
    print(a,'is greatest')
elif(b>c):
    print(b,'is greatest')
else:
    print(c,'is greatest')
    
