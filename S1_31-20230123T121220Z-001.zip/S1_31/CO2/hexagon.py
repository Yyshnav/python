def perimeter():
    s=int(input("Enter the length of side"))
    p=6*s
    print("Perimeter=",p)


perimeter()
