even={2,4,6,8,10}
square={1,4,9,16,25,36,49,64,81,100}
print(even)
print(square)
print(even.union(square))
print(even.intersection(square))
print(even.difference(square))
