name={"Niranjan","Avinash","Shabna","Adwaith","Adwaith","Akash","Akash"}
print(name)
print(type(name))
