name=input("Enter your name")
age=int(input("Enter your age"))
add=input("Enter your address")
print(name)
print(age)
print(add)

