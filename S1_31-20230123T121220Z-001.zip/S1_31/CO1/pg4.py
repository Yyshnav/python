name=input("Enter your name")
print(len(name))
n=len(name)
print(name[-1])
