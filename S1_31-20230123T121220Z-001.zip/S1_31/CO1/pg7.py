list_color=['black','red','blue','green','white']
print(list_color)
list_color.append('grey')
print(list_color)
list_color.insert(3,'yellow')
print(list_color)
list_color.pop(-1)
list_color.append('purple')
print(list_color)

