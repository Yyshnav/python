a={1,3,5,7,9}
print(a)
a.add(11)
print(a)
a.remove(5)
print(a)