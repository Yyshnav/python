list_a=[1,2,3,4,5]
print(list_a)
print(len(list_a))
print(max(list_a))
print(min(list_a))
