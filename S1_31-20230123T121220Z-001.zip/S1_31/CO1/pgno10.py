r=int(input("Enter the radius"))
a=3.14*r*r
print("Area=",a)
