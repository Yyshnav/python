dict_1={1:"a",2:"b",3:"f"}
dict_2={3:"f",4:"d"}
print(dict_1 | dict_2)
