list_fruits=["apple","banana","cherry"]
print("list=",list_fruits)
tup1=tuple(list_fruits)
print("tuple=",tup1)
