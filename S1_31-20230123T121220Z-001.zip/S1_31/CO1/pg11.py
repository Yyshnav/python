set_a={6,3,4,8,2,9}
print("length=",len(set_a))
print("minimum of set=",min(set_a))
print("maximum of set=",max(set_a))
print("sum of set=",sum(set_a))
print("sorted=",sorted(set_a))
