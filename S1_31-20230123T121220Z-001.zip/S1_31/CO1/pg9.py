tup_mark=(50,60,70,40,30,55)
print("length=",len(tup_mark))
print("maximum=",max(tup_mark))
print("minimum=",min(tup_mark))
